-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2022 at 10:19 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ce2`
--

-- --------------------------------------------------------

--
-- Table structure for table `acheter`
--

CREATE TABLE `acheter` (
  `Id_Achat` int(11) NOT NULL,
  `Id_Prod` int(11) DEFAULT NULL,
  `Qt_Gros` double DEFAULT NULL,
  `Qt_Detail` double DEFAULT NULL,
  `Prix_Gros` double DEFAULT NULL,
  `Prix_Detail` double DEFAULT NULL,
  `Date_expi` varchar(7) DEFAULT NULL,
  `Date_achat` varchar(10) DEFAULT NULL,
  `Type_Achat` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cardex`
--

CREATE TABLE `cardex` (
  `Id_cardex` int(11) NOT NULL,
  `Id_cons` int(11) NOT NULL,
  `Id_traitement` int(11) NOT NULL,
  `TC` varchar(5) DEFAULT NULL,
  `TAD` varchar(5) DEFAULT NULL,
  `TAS` varchar(5) DEFAULT NULL,
  `FC` varchar(5) DEFAULT NULL,
  `FR` varchar(5) DEFAULT NULL,
  `SaO` varchar(5) DEFAULT NULL,
  `Glycemie` varchar(5) DEFAULT NULL,
  `Date` varchar(15) NOT NULL,
  `Heure` varchar(10) NOT NULL,
  `Observation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `consommation`
--

CREATE TABLE `consommation` (
  `Id_Conso` int(11) NOT NULL,
  `Id_Prod` int(11) NOT NULL,
  `Id_Cons` int(11) NOT NULL,
  `Prix_Conso` double DEFAULT NULL,
  `QT_Conso` double DEFAULT NULL,
  `Date_Conso` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE `consultation` (
  `Id_consultation` int(11) NOT NULL,
  `Id_pr` int(11) NOT NULL,
  `Id_pa` int(11) NOT NULL,
  `s` text DEFAULT NULL,
  `ATCD` text DEFAULT NULL,
  `HMA` text DEFAULT NULL,
  `CA` text DEFAULT NULL,
  `EP` text DEFAULT NULL,
  `A` text DEFAULT NULL,
  `CAT` text DEFAULT NULL,
  `Date` text NOT NULL,
  `Heure` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `covid`
--

CREATE TABLE `covid` (
  `Id_covid` int(11) NOT NULL,
  `date` date NOT NULL,
  `Id_pa` int(11) NOT NULL,
  `id_user_labo` varchar(50) DEFAULT NULL,
  `id_user_rec` varchar(50) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `resultat` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `evolution`
--

CREATE TABLE `evolution` (
  `Id_ev` int(11) NOT NULL,
  `S` text DEFAULT NULL,
  `HMA` text DEFAULT NULL,
  `CA` text DEFAULT NULL,
  `EP` text DEFAULT NULL,
  `A` text DEFAULT NULL,
  `Date` text NOT NULL,
  `Id_pr` int(11) NOT NULL,
  `Id_pa` int(11) NOT NULL,
  `Id_con` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `examen`
--

CREATE TABLE `examen` (
  `Id_examen` int(11) NOT NULL,
  `Examen` varchar(25) DEFAULT NULL,
  `Type` varchar(35) DEFAULT NULL,
  `Prix` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `facture`
--

CREATE TABLE `facture` (
  `id_fac` int(11) NOT NULL,
  `prestation` varchar(100) NOT NULL,
  `prix` double NOT NULL,
  `id_cons` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `honoraire`
--

CREATE TABLE `honoraire` (
  `id_h` int(11) NOT NULL,
  `prestation` varchar(100) NOT NULL,
  `qte` double DEFAULT NULL,
  `pu` double NOT NULL,
  `pt` double NOT NULL,
  `id_cons` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `imagerie`
--

CREATE TABLE `imagerie` (
  `Id_im` int(11) NOT NULL,
  `Exs` text DEFAULT NULL,
  `Exd` text NOT NULL,
  `Rec` text DEFAULT NULL,
  `But` text DEFAULT NULL,
  `Date` varchar(20) DEFAULT NULL,
  `Dr_in` varchar(20) DEFAULT NULL,
  `Interpretation` text DEFAULT NULL,
  `Id_cons` int(11) NOT NULL,
  `Id_ev` int(11) DEFAULT NULL,
  `sorte` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `labo`
--

CREATE TABLE `labo` (
  `Id_la` int(11) NOT NULL,
  `Id_pa` int(11) NOT NULL,
  `Id_cons` int(11) NOT NULL,
  `Id_ev` int(11) DEFAULT NULL,
  `Id_per` int(11) DEFAULT NULL,
  `Nom_ex` varchar(25) NOT NULL,
  `Type_ex` varchar(25) NOT NULL,
  `Valeur` varchar(80) DEFAULT NULL,
  `sorte` varchar(50) DEFAULT NULL,
  `prix` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id_pa` int(11) NOT NULL,
  `Nom` varchar(80) NOT NULL,
  `Post_nom` varchar(80) NOT NULL,
  `Prenom` varchar(80) NOT NULL,
  `Sexe` varchar(80) NOT NULL,
  `DN` varchar(80) NOT NULL,
  `EC` varchar(80) NOT NULL,
  `Adresse` varchar(80) NOT NULL,
  `Phone` varchar(80) DEFAULT NULL,
  `Profession` varchar(80) DEFAULT NULL,
  `Employeur` varchar(80) DEFAULT NULL,
  `ATCD` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `personnel`
--

CREATE TABLE `personnel` (
  `Id_pr` int(11) NOT NULL,
  `Nom` varchar(80) NOT NULL,
  `Post_nom` varchar(80) NOT NULL,
  `Prenom` varchar(80) NOT NULL,
  `Sexe` varchar(80) NOT NULL,
  `Adresse` varchar(80) NOT NULL,
  `Fonction` varchar(80) NOT NULL,
  `Mot_de_passe` varchar(25) NOT NULL,
  `CNOM` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacie`
--

CREATE TABLE `pharmacie` (
  `Id_pharmacie` int(11) NOT NULL,
  `Produit` varchar(37) DEFAULT NULL,
  `Qt` varchar(10) DEFAULT NULL,
  `Prix` varchar(7) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL,
  `Prix_Achat` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `id_Prod` int(3) NOT NULL,
  `Nom_Prod` varchar(38) DEFAULT NULL,
  `Qt_Prod` int(2) DEFAULT NULL,
  `PU_Prod` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sv`
--

CREATE TABLE `sv` (
  `Id_sv` int(11) NOT NULL,
  `Id_pa` int(11) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `Heure` varchar(25) NOT NULL,
  `TC` varchar(10) DEFAULT NULL,
  `TAS` varchar(10) DEFAULT NULL,
  `TAD` varchar(10) DEFAULT NULL,
  `FC` varchar(10) DEFAULT NULL,
  `FR` varchar(10) DEFAULT NULL,
  `O` varchar(80) DEFAULT NULL,
  `Poid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tarif_imagerie`
--

CREATE TABLE `tarif_imagerie` (
  `Id_imagerie` int(11) NOT NULL,
  `Exploration` varchar(100) NOT NULL,
  `Prix` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `total`
--

CREATE TABLE `total` (
  `id_to` int(11) NOT NULL,
  `TG` double NOT NULL,
  `CV` double NOT NULL,
  `SNP` double NOT NULL,
  `SR` double NOT NULL,
  `id_cons` int(11) DEFAULT NULL,
  `Type` varchar(11) NOT NULL,
  `id_fac` int(11) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `traitement`
--

CREATE TABLE `traitement` (
  `Id_tr` int(11) NOT NULL,
  `Medicament` varchar(1000) DEFAULT NULL,
  `Qt_prise` varchar(25) DEFAULT NULL,
  `Type` varchar(25) DEFAULT NULL,
  `mode_emploi` varchar(100) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `Source` varchar(10) DEFAULT NULL,
  `Id_ev` int(11) DEFAULT NULL,
  `Id_pa` int(11) DEFAULT NULL,
  `Id_cons` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `covid`
--
ALTER TABLE `covid`
  ADD PRIMARY KEY (`Id_covid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id_pa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `covid`
--
ALTER TABLE `covid`
  MODIFY `Id_covid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id_pa` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
